/*
********************
# Copyright (c) 2021 Oracle and/or its affiliates. All rights reserved.
# by - Rene Fontcha - Oracle LiveLabs Platform Lead
# Last Updated - 10/26/2022
********************
*/

terraform {
  required_version = "~> 1.5.0"
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = "= 8.29.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "= 3.5.1"
    }
    tls = {
      source  = "hashicorp/tls"
      version = "= 4.0.4"
    }
    time = {
      source  = "hashicorp/time"
      version = "= 0.9.1"
    }
  }
}

provider "oci" {
  tenancy_ocid = var.tenancy_ocid
  region       = var.region
}
